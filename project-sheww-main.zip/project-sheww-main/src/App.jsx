// src/App.jsx
import React from "react";
import HomePage from "./HomePage";

const App = () => {
  return (
    <div>
      <HomePage />
    </div>
  );
};

export default App;
